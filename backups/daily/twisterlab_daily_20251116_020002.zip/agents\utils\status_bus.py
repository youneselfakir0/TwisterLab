"""
StatusBus - Redis-backed agent status bus for TwisterLab
Provides publish and retrieve abilities for agent status and alerts.
Falls back to in-memory storage if Redis is not available.
"""

import asyncio
import json
import logging
import os
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)

try:
    import aioredis
    AIREDIS_AVAILABLE = True
except Exception:
    AIREDIS_AVAILABLE = False


class StatusBus:
    """Status bus for sharing agent status and logs across agents.

    Uses Redis pub/sub and key/value storage for easy access by other agents and orchestrators.
    If Redis is not available, falls back to an in-memory dictionary (best-effort mode).
    """

    def __init__(self, redis_url: Optional[str] = None):
        self.redis_url = redis_url or os.getenv("REDIS_URL", "redis://localhost:6379")
        self._redis = None  # type: Optional[aioredis.Redis]
        self._in_memory: Dict[str, Dict[str, Any]] = {}
        self._connected = False

    async def _connect(self):
        if AIREDIS_AVAILABLE and not self._connected:
            try:
                self._redis = await aioredis.from_url(self.redis_url)
                self._connected = True
            except Exception as e:
                logger.warning(f"StatusBus: Failed to connect to Redis at {self.redis_url}: {e}")
                self._connected = False

    async def publish_status(self, agent_name: str, status: Dict[str, Any], ttl: int = 3600) -> bool:
        """Publish the status for an agent, and optionally notify subscribers.

        Stores the status at key `twisterlab:agent_status:{agent_name}` and publishes on channel.
        """
        try:
            await self._connect()
            payload = json.dumps(status, default=str)

            if AIREDIS_AVAILABLE and self._connected and self._redis:
                key = f"twisterlab:agent_status:{agent_name}"
                await self._redis.set(key, payload, ex=ttl)
                await self._redis.publish("twisterlab:agent_status_updates", payload)
            else:
                # Fallback to in-memory
                self._in_memory[agent_name] = status

            return True

        except Exception as e:
            logger.error(f"StatusBus.publish_status failed: {e}")
            # last-resort fallback: in-memory
            self._in_memory[agent_name] = status
            return False

    async def get_status(self, agent_name: str) -> Optional[Dict[str, Any]]:
        """Retrieve the last known status for an agent."""
        try:
            await self._connect()
            if AIREDIS_AVAILABLE and self._connected and self._redis:
                key = f"twisterlab:agent_status:{agent_name}"
                raw = await self._redis.get(key)
                if raw is None:
                    return None
                return json.loads(raw)
            else:
                return self._in_memory.get(agent_name)

        except Exception as e:
            logger.error(f"StatusBus.get_status failed: {e}")
            return self._in_memory.get(agent_name)

    async def list_statuses(self) -> Dict[str, Dict[str, Any]]:
        """List all known agent statuses."""
        try:
            await self._connect()
            if AIREDIS_AVAILABLE and self._connected and self._redis:
                keys = await self._redis.keys("twisterlab:agent_status:*")
                res = {}
                for k in keys:
                    raw = await self._redis.get(k)
                    if raw:
                        name = k.decode().split(":")[-1] if isinstance(k, bytes) else k.split(":")[-1]
                        res[name] = json.loads(raw)
                return res
            else:
                return self._in_memory.copy()

        except Exception as e:
            logger.error(f"StatusBus.list_statuses failed: {e}")
            return self._in_memory.copy()


# Provide a module-level default bus for convenience
DEFAULT_STATUS_BUS: Optional[StatusBus] = None

async def get_default_bus() -> StatusBus:
    global DEFAULT_STATUS_BUS
    if DEFAULT_STATUS_BUS is None:
        DEFAULT_STATUS_BUS = StatusBus()
        await DEFAULT_STATUS_BUS._connect()
    return DEFAULT_STATUS_BUS
