"""
TwisterLab - Real Working Desktop Commander Agent (v2 - Unified)
Executes system commands securely on Windows/Linux, aligned with the UnifiedAgentBase.
"""

import asyncio
import logging
import platform
import subprocess
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from agents.base.unified_agent import AgentStatus
from agents.base import accepts_context_or_task
from agents.desktop_commander.desktop_commander_agent import DesktopCommanderAgent, CommandStatus

# Import LLM client for intelligent command validation
try:
    from agents.base.llm_client import ollama_client

    LLM_AVAILABLE = True
except ImportError:
    LLM_AVAILABLE = False

logger = logging.getLogger(__name__)


class RealDesktopCommanderAgent(DesktopCommanderAgent):
    """
    Real desktop commander that executes ACTUAL system commands. Inherits from UnifiedAgentBase.
    """

    def __init__(self):
        super().__init__()
        # If LLM is available enable LLM validation; otherwise default to False
        self.use_llm = LLM_AVAILABLE  # Enable LLM validation if available
    # DesktopCommanderAgent defines WHITELISTED_COMMANDS and related implementations.

    @accepts_context_or_task
    async def execute(self, task_or_context, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute desktop commander operation.
        This method is called by the parent 'run' method, which handles status and error management.

        Args:
            context: Must contain 'operation' key
                Operations: execute_command, check_service, get_system_info, network_diagnostic

        Returns:
            Command execution results
        """
        # Normalize: if we received context only, decorator did normalization
        if isinstance(task_or_context, dict) and context is None:
            context = task_or_context
            task = context.get("operation", "execute_command")
        else:
            task = task_or_context
        # Delegate to DesktopCommanderAgent for standard behavior
        return await super().execute(task, context)

    async def _execute_command(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute system command with STRICT whitelist validation.
        """
        # Use DesktopCommanderAgent whitelisting and parameter validation
        command = context.get("command")
        parameters = context.get("parameters", {})
        # If LLM is enabled, perform LLM validation step first; if validation errors occur, continue normal flow
        if self.use_llm:
            try:
                is_safe_llm = await self._validate_command_llm(command, list(parameters.values()))
                if not is_safe_llm:
                    logger.warning(f"⚠️ LLM flagged whitelisted command as potentially unsafe: {command}")
                    return {"status": "rejected", "reason": "LLM flagged command as unsafe"}
            except Exception as llm_error:
                # If LLM is unavailable or errors, don't reject the command; rely on whitelist and validation
                logger.warning(f"⚠️ LLM validation failed (continuing due to fallback): {llm_error}")
        # Delegate to core implementation for main execution flow
        return await super()._execute_command(context)
        if not is_whitelisted:
            raise ValueError(f"Command not in whitelist: {command}")

        if self.use_llm:
            try:
                is_safe_llm = await self._validate_command_llm(command, args)
                if not is_safe_llm:
                    logger.warning(
                        f"⚠️ LLM flagged whitelisted command as potentially unsafe: {command}"
                    )
            except Exception as llm_error:
                logger.warning(f"⚠️ LLM validation failed (ignored, whitelist passed): {llm_error}")

        cmd_config = self.safe_commands[command]
        os_key = "windows" if self.os_type == "Windows" else "linux"
        actual_command = cmd_config.get(os_key, cmd_config.get("windows"))
        cmd_args = args if args else cmd_config.get("args", [])
        full_command = [actual_command] + cmd_args

        logger.info(f"🔧 Executing: {' '.join(full_command)}")
        start_time = datetime.now(timezone.utc)

        try:
            process = await asyncio.create_subprocess_exec(
                *full_command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=30.0)
            execution_time = (datetime.now(timezone.utc) - start_time).total_seconds()

            return {
                "status": "success" if process.returncode == 0 else "failed",
                "command": command,
                "full_command": " ".join(full_command),
                "return_code": process.returncode,
                "output": stdout.decode("utf-8", errors="ignore")[:5000],
                "error": stderr.decode("utf-8", errors="ignore")[:1000] if stderr else None,
                "execution_time_seconds": round(execution_time, 2),
            }
        except asyncio.TimeoutError:
            raise TimeoutError(f"Command execution timeout (30s) for {command}")
        except Exception as e:
            raise RuntimeError(f"Command execution failed for {command}: {e}")

    async def _check_service(self, service_name: str) -> Dict[str, Any]:
        """Checks Windows/Linux service status."""
        logger.info(f"🔍 Checking service: {service_name}")
        command = (
            ["sc", "query", service_name]
            if self.os_type == "Windows"
            else ["systemctl", "status", service_name]
        )
        try:
            process = await asyncio.create_subprocess_exec(
                *command, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
            )
            stdout, _ = await process.communicate()
            output = stdout.decode("utf-8", errors="ignore")
            is_running = (
                ("RUNNING" in output)
                if self.os_type == "Windows"
                else ("active (running)" in output)
            )
            return {
                "status": "success",
                "service_name": service_name,
                "is_running": is_running,
                "output": output[:1000],
            }
        except Exception as e:
            raise RuntimeError(f"Service check failed for {service_name}: {e}")

    async def _get_system_info(self) -> Dict[str, Any]:
        """Gathers comprehensive system information."""
        logger.info("📊 Gathering system information...")
        import psutil

        return {
            "status": "success",
            "system_info": {
                "hostname": platform.node(),
                "os": {"system": platform.system(), "release": platform.release()},
                "cpu": {"count": psutil.cpu_count(), "percent": psutil.cpu_percent(interval=1)},
                "memory": {
                    "total_gb": round(psutil.virtual_memory().total / (1024**3), 2),
                    "percent": psutil.virtual_memory().percent,
                },
                "disk": {
                    "total_gb": round(psutil.disk_usage("/").total / (1024**3), 2),
                    "percent": psutil.disk_usage("/").percent,
                },
                "available_commands": list(self.safe_commands.keys()),
            },
        }

    async def _network_diagnostic(self, target: str) -> Dict[str, Any]:
        """Runs comprehensive network diagnostics."""
        logger.info(f"🌐 Running network diagnostics for {target}...")
        diagnostics = {}
        ping_result = await self._execute_command("ping", [target])
        diagnostics["ping"] = {
            "success": ping_result["status"] == "success",
            "output": ping_result.get("output", "")[:500],
        }
        nslookup_result = await self._execute_command("nslookup", [target])
        diagnostics["dns_resolution"] = {
            "success": nslookup_result["status"] == "success",
            "output": nslookup_result.get("output", "")[:500],
        }

        overall_health = (
            "healthy" if all(d.get("success", False) for d in diagnostics.values()) else "degraded"
        )
        return {
            "status": "success",
            "target": target,
            "diagnostics": diagnostics,
            "overall_health": overall_health,
        }

    async def _validate_command_llm(self, command: str, args: List[str] = None) -> bool:
        """Uses LLM to validate command safety."""
        full_cmd = f"{command} {' '.join(args or [])}"
        prompt = f"""Is this command safe for IT diagnostics? Command: {full_cmd}. Safe commands are READ-ONLY. Unsafe commands MODIFY system. Answer YES or NO."""
        try:
            result = await ollama_client.generate_with_fallback(
                prompt=prompt, agent_type="commander"
            )
            is_safe = result["response"].strip().upper().startswith("YES")
            logger.info(f"🤖 LLM validation for '{full_cmd}': {'SAFE' if is_safe else 'UNSAFE'}")
            return is_safe
        except Exception as e:
            logger.error(f"❌ LLM validation error: {e}")
            # Default to SAFE on LLM validation failure (do not reject based on LLM errors)
            return True

    async def _validate_command_whitelist(self, command: str) -> bool:
        """Validates command against static whitelist."""
        is_whitelisted = command in self.safe_commands
        logger.info(
            f"✅ Whitelist validated: {command}"
            if is_whitelisted
            else f"❌ Command not whitelisted: {command}"
        )
        return is_whitelisted
