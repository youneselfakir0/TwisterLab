"""
TwisterLab - Autonomous Monitoring Agent
Self-monitoring, self-healing agent with Prometheus metrics and auto-recovery.
"""

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional
import aiohttp
import psutil
import docker
from docker.errors import DockerException

from agents.base import AutonomousTwisterAgent

logger = logging.getLogger(__name__)


class AutonomousMonitoringAgent(AutonomousTwisterAgent):
    """
    Autonomous monitoring agent with self-healing capabilities.

    Features:
    - Real-time system health monitoring
    - Docker service health checks
    - Network connectivity validation
    - GPU monitoring (if available)
    - Auto-recovery for failed services
    - Prometheus metrics integration
    - Structured logging with correlation IDs
    """

    def __init__(self):
        super().__init__(
            name="autonomous_monitoring",
            display_name="Autonomous Monitoring Agent",
            description="Self-monitoring system health guardian with auto-recovery",
            role="monitor",
            model="llama-3.2",
            temperature=0.3,  # Lower temperature for consistent monitoring
            enable_autonomy=True,
            health_check_interval=30,  # More frequent checks
            auto_recovery=True,
            max_recovery_attempts=5,
            performance_monitoring=True,
            metadata={
                "version": "2.0.0",
                "capabilities": ["system_monitoring", "docker_health", "network_checks", "gpu_monitoring", "auto_recovery"],
                "recovery_strategies": ["service_restart", "cache_clear", "state_reset", "maestro_escalation"]
            }
        )

        # Monitoring configuration
        self.thresholds = {
            "cpu_percent": 80,
            "memory_percent": 85,
            "disk_percent": 90,
            "gpu_memory_percent": 85
        }

        # Expected services - match Docker service names
        self.expected_services = [
            "twisterlab_api",
            "twisterlab_postgres",
            "twisterlab_redis",
            "twisterlab_prometheus",
            "twisterlab_grafana",
            "twisterlab_ollama"
        ]

        # Expected ports with service mapping
        self.expected_ports = {
            8000: {"service": "API", "protocol": "http", "health_endpoint": "/health"},
            5432: {"service": "PostgreSQL", "protocol": "tcp"},
            6379: {"service": "Redis", "protocol": "tcp"},
            9090: {"service": "Prometheus", "protocol": "http", "health_endpoint": "/-/healthy"},
            3000: {"service": "Grafana", "protocol": "http"},
            11434: {"service": "Ollama", "protocol": "http", "health_endpoint": "/api/tags"}
        }

        # Docker client
        self.docker_client = None
        self._init_docker_client()

        # Recovery state
        self.failed_services = set()
        self.last_recovery_attempt = {}

    def _init_docker_client(self):
        """Initialize Docker client with error handling."""
        try:
            self.docker_client = docker.from_env()
        except DockerException as e:
            self.logger.warning(f"Docker client initialization failed: {e}")
            self.docker_client = None

    async def _execute_task(self, task: str, context: Optional[Dict[str, Any]] = None) -> Any:
        """Execute monitoring tasks with comprehensive error handling."""
        correlation_id = context.get('correlation_id', str(uuid.uuid4())) if context else str(uuid.uuid4())

        self.logger.info(
            f"Executing monitoring task: {task}",
            extra={
                'correlation_id': correlation_id,
                'task': task,
                'context': context
            }
        )

        if task == "health_check":
            return await self._perform_comprehensive_health_check(correlation_id)
        elif task == "check_services":
            return await self._check_docker_services(correlation_id)
        elif task == "check_ports":
            return await self._check_network_ports(correlation_id)
        elif task == "check_gpu":
            return await self._check_gpu_status(correlation_id)
        elif task == "full_diagnostic":
            return await self._perform_full_diagnostic(correlation_id)
        elif task == "recover_service":
            service_name = context.get('service_name') if context else None
            return await self._recover_service(service_name, correlation_id)
        else:
            raise ValueError(f"Unknown monitoring task: {task}")

    async def _perform_comprehensive_health_check(self, correlation_id: str) -> Dict[str, Any]:
        """Perform comprehensive system health check."""
        results = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "correlation_id": correlation_id,
            "overall_status": "unknown",
            "system_health": {},
            "services_health": {},
            "network_health": {},
            "gpu_health": {},
            "recommendations": []
        }

        try:
            # System health
            results["system_health"] = await self._check_system_resources()

            # Services health
            results["services_health"] = await self._check_docker_services(correlation_id)

            # Network health
            results["network_health"] = await self._check_network_ports(correlation_id)

            # GPU health
            results["gpu_health"] = await self._check_gpu_status(correlation_id)

            # Determine overall status
            all_checks = [
                results["system_health"].get("status", "unknown"),
                results["services_health"].get("status", "unknown"),
                results["network_health"].get("status", "unknown"),
                results["gpu_health"].get("status", "unknown")
            ]

            if all(status == "healthy" for status in all_checks):
                results["overall_status"] = "healthy"
            elif any(status in ["critical", "unhealthy"] for status in all_checks):
                results["overall_status"] = "critical"
            elif any(status == "degraded" for status in all_checks):
                results["overall_status"] = "degraded"
            else:
                results["overall_status"] = "degraded"

            # Generate recommendations
            results["recommendations"] = self._generate_recommendations(results)

        except Exception as e:
            results["overall_status"] = "critical"
            results["error"] = str(e)
            self.logger.error(
                f"Comprehensive health check failed: {e}",
                extra={'correlation_id': correlation_id},
                exc_info=True
            )

        return results

    async def _check_system_resources(self) -> Dict[str, Any]:
        """Check basic system resources."""
        try:
            # CPU usage
            cpu_percent = psutil.cpu_percent(interval=1)

            # Memory usage
            memory = psutil.virtual_memory()
            memory_percent = memory.percent
            memory_used_gb = memory.used / (1024**3)
            memory_total_gb = memory.total / (1024**3)

            # Disk usage
            disk = psutil.disk_usage('/')
            disk_percent = disk.percent
            disk_used_gb = disk.used / (1024**3)
            disk_total_gb = disk.total / (1024**3)

            # Determine status
            issues = []
            if cpu_percent > self.thresholds["cpu_percent"]:
                issues.append(f"High CPU usage: {cpu_percent:.1f}%")
            if memory_percent > self.thresholds["memory_percent"]:
                issues.append(f"High memory usage: {memory_percent:.1f}%")
            if disk_percent > self.thresholds["disk_percent"]:
                issues.append(f"High disk usage: {disk_percent:.1f}%")

            status = "healthy" if not issues else "degraded"
            if len(issues) > 2:
                status = "critical"

            return {
                "status": status,
                "cpu_percent": cpu_percent,
                "memory_percent": memory_percent,
                "memory_used_gb": round(memory_used_gb, 2),
                "memory_total_gb": round(memory_total_gb, 2),
                "disk_percent": disk_percent,
                "disk_used_gb": round(disk_used_gb, 2),
                "disk_total_gb": round(disk_total_gb, 2),
                "issues": issues
            }

        except Exception as e:
            return {
                "status": "critical",
                "error": str(e)
            }

    async def _check_docker_services(self, correlation_id: str) -> Dict[str, Any]:
        """Check Docker services health."""
        if not self.docker_client:
            return {"status": "unknown", "error": "Docker client not available"}

        try:
            services_status = {}
            all_healthy = True

            for service_name in self.expected_services:
                try:
                    service = self.docker_client.services.get(service_name)
                    tasks = service.tasks()

                    running_tasks = [task for task in tasks if task.get('Status', {}).get('State') == 'running']
                    failed_tasks = [task for task in tasks if task.get('Status', {}).get('State') in ['failed', 'rejected']]

                    service_healthy = len(running_tasks) > 0 and len(failed_tasks) == 0

                    services_status[service_name] = {
                        "healthy": service_healthy,
                        "running_tasks": len(running_tasks),
                        "failed_tasks": len(failed_tasks),
                        "desired_replicas": service.attrs.get('Spec', {}).get('Mode', {}).get('Replicated', {}).get('Replicas', 0)
                    }

                    if not service_healthy:
                        all_healthy = False
                        self.failed_services.add(service_name)

                except docker.errors.NotFound:
                    services_status[service_name] = {"healthy": False, "error": "Service not found"}
                    all_healthy = False
                    self.failed_services.add(service_name)
                except Exception as e:
                    services_status[service_name] = {"healthy": False, "error": str(e)}
                    all_healthy = False
                    self.failed_services.add(service_name)

            # Auto-recovery for failed services
            if not all_healthy and self.auto_recovery:
                await self._attempt_service_recovery(correlation_id)

            return {
                "status": "healthy" if all_healthy else "critical",
                "services": services_status,
                "failed_services": list(self.failed_services)
            }

        except Exception as e:
            return {
                "status": "critical",
                "error": str(e)
            }

    async def _check_network_ports(self, correlation_id: str) -> Dict[str, Any]:
        """Check network port accessibility."""
        results = {}
        all_accessible = True

        for port, config in self.expected_ports.items():
            try:
                # For HTTP services, try to connect and check health endpoint
                if config["protocol"] == "http" and "health_endpoint" in config:
                    health_url = f"http://localhost:{port}{config['health_endpoint']}"
                    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=5)) as session:
                        async with session.get(health_url) as response:
                            is_healthy = response.status == 200
                            results[port] = {
                                "service": config["service"],
                                "accessible": True,
                                "healthy": is_healthy,
                                "status_code": response.status
                            }
                            if not is_healthy:
                                all_accessible = False
                else:
                    # For TCP services, just check if port is open
                    # This is a simplified check - in production you'd use socket connections
                    results[port] = {
                        "service": config["service"],
                        "accessible": True,  # Assume accessible for now
                        "protocol": config["protocol"]
                    }

            except Exception as e:
                results[port] = {
                    "service": config["service"],
                    "accessible": False,
                    "error": str(e)
                }
                all_accessible = False

        return {
            "status": "healthy" if all_accessible else "degraded",
            "ports": results
        }

    async def _check_gpu_status(self, correlation_id: str) -> Dict[str, Any]:
        """Check GPU status if available."""
        try:
            # Try to import GPU monitoring libraries
            try:
                import GPUtil
                gpus = GPUtil.getGPUs()

                if not gpus:
                    return {"status": "unknown", "message": "No GPUs detected"}

                gpu_status = []
                all_healthy = True

                for gpu in gpus:
                    gpu_info = {
                        "id": gpu.id,
                        "name": gpu.name,
                        "memory_used_percent": gpu.memoryUsed * 100.0 / gpu.memoryTotal,
                        "memory_free_mb": gpu.memoryFree,
                        "memory_used_mb": gpu.memoryUsed,
                        "memory_total_mb": gpu.memoryTotal,
                        "temperature": gpu.temperature
                    }

                    if gpu_info["memory_used_percent"] > self.thresholds["gpu_memory_percent"]:
                        gpu_info["status"] = "degraded"
                        all_healthy = False
                    else:
                        gpu_info["status"] = "healthy"

                    gpu_status.append(gpu_info)

                return {
                    "status": "healthy" if all_healthy else "degraded",
                    "gpus": gpu_status
                }

            except ImportError:
                return {"status": "unknown", "message": "GPU monitoring not available"}

        except Exception as e:
            return {
                "status": "critical",
                "error": str(e)
            }

    async def _perform_full_diagnostic(self, correlation_id: str) -> Dict[str, Any]:
        """Perform complete system diagnostic."""
        diagnostic = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "correlation_id": correlation_id,
            "agent_health": self.get_health_status().__dict__,
            "system_diagnostic": {},
            "services_diagnostic": {},
            "network_diagnostic": {},
            "performance_metrics": {},
            "recommendations": []
        }

        # Run all checks
        diagnostic["system_diagnostic"] = await self._check_system_resources()
        diagnostic["services_diagnostic"] = await self._check_docker_services(correlation_id)
        diagnostic["network_diagnostic"] = await self._check_network_ports(correlation_id)

        # Performance metrics
        diagnostic["performance_metrics"] = self.get_metrics_endpoint()

        # Generate comprehensive recommendations
        diagnostic["recommendations"] = self._generate_comprehensive_recommendations(diagnostic)

        return diagnostic

    async def _recover_service(self, service_name: str, correlation_id: str) -> Dict[str, Any]:
        """Attempt to recover a specific service."""
        if not service_name:
            return {"status": "error", "message": "No service name provided"}

        if not self.docker_client:
            return {"status": "error", "message": "Docker client not available"}

        try:
            service = self.docker_client.services.get(service_name)

            # Force update to restart service
            service.update(force_update=True)

            # Wait a bit for restart
            await asyncio.sleep(5)

            # Check if service is now healthy
            tasks = service.tasks()
            running_tasks = [task for task in tasks if task.get('Status', {}).get('State') == 'running']

            success = len(running_tasks) > 0

            return {
                "status": "success" if success else "failed",
                "service": service_name,
                "running_tasks": len(running_tasks),
                "action": "service_restart"
            }

        except Exception as e:
            return {
                "status": "error",
                "service": service_name,
                "error": str(e)
            }

    async def _attempt_service_recovery(self, correlation_id: str):
        """Attempt to recover failed services."""
        for service_name in list(self.failed_services):
            # Rate limiting for recovery attempts
            last_attempt = self.last_recovery_attempt.get(service_name, 0)
            if datetime.now(timezone.utc).timestamp() - last_attempt < 300:  # 5 minutes
                continue

            self.last_recovery_attempt[service_name] = datetime.now(timezone.utc).timestamp()

            result = await self._recover_service(service_name, correlation_id)

            if result["status"] == "success":
                self.failed_services.discard(service_name)
                self.logger.info(
                    f"Successfully recovered service: {service_name}",
                    extra={'correlation_id': correlation_id, 'service': service_name}
                )
            else:
                self.logger.warning(
                    f"Failed to recover service: {service_name}",
                    extra={'correlation_id': correlation_id, 'service': service_name, 'error': result.get('error')}
                )

    async def _agent_specific_health_check(self):
        """Agent-specific health checks for monitoring agent."""
        # Check if we can access Docker
        if self.docker_client:
            try:
                self.docker_client.ping()
                self.health_status.metadata["docker_accessible"] = True
            except:
                self.health_status.metadata["docker_accessible"] = False
        else:
            self.health_status.metadata["docker_accessible"] = False

        # Check failed services count
        self.health_status.metadata["failed_services_count"] = len(self.failed_services)

    def _generate_recommendations(self, health_results: Dict[str, Any]) -> List[str]:
        """Generate health recommendations based on check results."""
        recommendations = []

        # System recommendations
        system = health_results.get("system_health", {})
        if system.get("status") == "critical":
            recommendations.append("⚠️ Critical system resource usage detected - immediate action required")
        elif system.get("status") == "degraded":
            recommendations.append("⚡ High resource usage detected - monitor closely")

        # Services recommendations
        services = health_results.get("services_health", {})
        failed_services = services.get("failed_services", [])
        if failed_services:
            recommendations.append(f"🔧 Failed services detected: {', '.join(failed_services)} - attempting auto-recovery")

        # Network recommendations
        network = health_results.get("network_health", {})
        if network.get("status") != "healthy":
            recommendations.append("🌐 Network connectivity issues detected - check service accessibility")

        return recommendations

    def _generate_comprehensive_recommendations(self, diagnostic: Dict[str, Any]) -> List[str]:
        """Generate comprehensive diagnostic recommendations."""
        recommendations = []

        # System-level recommendations
        system = diagnostic.get("system_diagnostic", {})
        if system.get("cpu_percent", 0) > 90:
            recommendations.append("🚨 CPU usage critically high - scale up infrastructure or optimize processes")
        if system.get("memory_percent", 0) > 95:
            recommendations.append("🚨 Memory usage critically high - add more RAM or optimize memory usage")

        # Service-level recommendations
        services = diagnostic.get("services_diagnostic", {}).get("services", {})
        unhealthy_services = [name for name, info in services.items() if not info.get("healthy", True)]
        if unhealthy_services:
            recommendations.append(f"🔧 Unhealthy services: {', '.join(unhealthy_services)} - check logs and restart")

        # Performance recommendations
        agent_health = diagnostic.get("agent_health", {})
        error_rate = agent_health.get("error_rate", 0)
        if error_rate > 0.1:
            recommendations.append("🔍 Elevated agent error rate detected - investigate logs and recovery status")
        if agent_health.get("memory_usage_mb", 0) > 1000:
            recommendations.append("⚡ High agent memory usage - monitor for memory leaks")

        return recommendations

    # Recovery strategies
    async def _recovery_restart_services(self, correlation_id: str, failed_task: str, context: Optional[Dict[str, Any]]) -> bool:
        """Restart failed services."""
        if self.failed_services:
            await self._attempt_service_recovery(correlation_id)
            return len(self.failed_services) == 0
        return True

    async def _recovery_clear_cache(self, correlation_id: str, failed_task: str, context: Optional[Dict[str, Any]]) -> bool:
        """Clear monitoring caches."""
        # Clear any cached data
        self.failed_services.clear()
        self.last_recovery_attempt.clear()
        return True

    async def _recovery_reset_state(self, correlation_id: str, failed_task: str, context: Optional[Dict[str, Any]]) -> bool:
        """Reset agent state."""
        self.health_status.checks_passed = 0
        self.health_status.checks_failed = 0
        self.health_status.error_rate = 0.0
        self.health_status.last_error = None
        return True
