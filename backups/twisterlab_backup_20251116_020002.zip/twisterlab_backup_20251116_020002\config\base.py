"""
TwisterLab Base Agent with Multi-Framework Schema Export.

Provides schema compatibility with:
- Microsoft Agent Framework
- LangChain Agents
- Semantic Kernel
- OpenAI Assistants API
"""

from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional
from agents.utils.status_bus import get_default_bus
from datetime import datetime, timezone
import json

try:
    from prometheus_client import Counter, Gauge, Histogram, Info
except ImportError:
    # Fallback for when prometheus is not available
    class Counter:
        def __init__(self, *args, **kwargs): pass
        def inc(self, *args, **kwargs): pass
        def labels(self, *args, **kwargs): return self

    class Gauge:
        def __init__(self, *args, **kwargs): pass
        def set(self, *args, **kwargs): pass
        def labels(self, *args, **kwargs): return self

    class Histogram:
        def __init__(self, *args, **kwargs): pass
        def observe(self, *args, **kwargs): pass
        def labels(self, *args, **kwargs): return self

    class Info:
        def __init__(self, *args, **kwargs): pass
        def info(self, *args, **kwargs): pass

from agents.base import TwisterAgent


@dataclass
class HealthStatus:
    """Agent health status information."""
    agent_name: str
    status: str = "unknown"  # healthy, degraded, unhealthy, critical
    last_check: str = ""
    checks_passed: int = 0
    checks_failed: int = 0
    uptime_seconds: float = 0.0
    memory_usage_mb: float = 0.0
    cpu_usage_percent: float = 0.0
    error_rate: float = 0.0
    last_error: Optional[str] = None
    recovery_attempts: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


class TwisterAgent(ABC):
    """
    Base class for all TwisterLab agents with multi-framework export support.

    Attributes:
        name: Agent unique identifier
        display_name: Human-readable agent name
        description: Agent purpose and capabilities
        role: Agent role in the system
        instructions: System instructions/prompt for the agent
        tools: List of available tools/functions
        model: LLM model to use (e.g., "gpt-4", "llama-3.2")
        temperature: LLM temperature setting
        metadata: Additional metadata
    """

    def __init__(
        self,
        name: str,
        display_name: str,
        description: str,
        role: str = "assistant",
        instructions: Optional[str] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        model: str = "llama-3.2",
        temperature: float = 0.7,
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.name = name
        self.display_name = display_name
        self.description = description
        self.role = role
        self.instructions = instructions or f"You are {display_name}, {description}"
        self.tools = tools or []
        self.model = model
        self.temperature = temperature
        self.metadata = metadata or {}
        self.created_at = datetime.now(timezone.utc).isoformat() + "Z"

    @abstractmethod
    async def execute(self, task: str, context: Optional[Dict[str, Any]] = None) -> Any:
        """Execute agent task (to be implemented by subclasses)."""
        pass

    def to_schema(self, format: str = "microsoft") -> Dict[str, Any]:
        """
        Export agent schema in standard format for interoperability.

        Args:
            format: Target format - "microsoft" | "langchain" | "semantic-kernel" | "openai"

        Returns:
            Dict conforming to the official specification of the target format

        Raises:
            ValueError: If format is not supported

        References:
            - Microsoft: https://learn.microsoft.com/en-us/azure/ai-services/agents/
            - LangChain: https://python.langchain.com/docs/modules/agents/
            - Semantic Kernel: https://learn.microsoft.com/en-us/semantic-kernel/overview/
            - OpenAI: https://platform.openai.com/docs/assistants/overview
        """
        format = format.lower()

        if format == "microsoft":
            return self._to_microsoft_schema()
        elif format == "langchain":
            return self._to_langchain_schema()
        elif format == "semantic-kernel":
            return self._to_semantic_kernel_schema()
        elif format == "openai":
            return self._to_openai_assistant_schema()
        else:
            raise ValueError(
                f"Unknown format: {format}. "
                f"Supported: microsoft, langchain, semantic-kernel, openai"
            )

    def _to_microsoft_schema(self) -> Dict[str, Any]:
        """
        Export to Microsoft Agent Framework format (Production-ready).

        Based on Microsoft Agent Framework specification:
        https://learn.microsoft.com/en-us/azure/ai-services/agents/

        Microsoft Agent Format:
        {
            "id": "agent-id",
            "object": "agent",
            "created_at": timestamp,
            "name": "Agent Name",
            "description": "Agent description",
            "model": "model-name",
            "instructions": "System instructions",
            "tools": [...],
            "metadata": {...}
        }
        """
        return {
            "id": self.name,
            "object": "agent",
            "created_at": int(datetime.fromisoformat(self.created_at.replace("Z", "+00:00")).timestamp()),
            "name": self.display_name,
            "description": self.description,
            "model": self.model,
            "instructions": self.instructions,
            "tools": self._convert_tools_to_microsoft_format(),
            "metadata": {
                **self.metadata,
                "role": self.role,
                "temperature": self.temperature,
                "framework": "twisterlab",
                "version": "1.0.0"
            }
        }

    def _to_langchain_schema(self) -> Dict[str, Any]:
        """
        Export to LangChain Agent format (Stub - v2.0 planned).

        Based on LangChain Agents specification:
        https://python.langchain.com/docs/modules/agents/

        LangChain Agent Format:
        {
            "name": "agent_name",
            "description": "Agent description",
            "llm": {...},
            "tools": [...],
            "agent_type": "zero-shot-react-description",
            "memory": {...}
        }
        """
        return {
            "_format": "langchain",
            "_status": "stub",
            "_note": "Full LangChain compatibility planned for v2.0",
            "name": self.name,
            "description": self.description,
            "llm": {
                "model_name": self.model,
                "temperature": self.temperature
            },
            "tools": [tool.get("function", {}).get("name", "unknown") for tool in self.tools],
            "agent_type": "zero-shot-react-description",
            "memory": None,
            "metadata": self.metadata
        }

    def _to_semantic_kernel_schema(self) -> Dict[str, Any]:
        """
        Export to Semantic Kernel format (Stub - v2.0 planned).

        Based on Semantic Kernel specification:
        https://learn.microsoft.com/en-us/semantic-kernel/overview/

        Semantic Kernel Format:
        {
            "name": "SkillName",
            "description": "Skill description",
            "functions": [...],
            "settings": {...}
        }
        """
        return {
            "_format": "semantic-kernel",
            "_status": "stub",
            "_note": "Full Semantic Kernel compatibility planned for v2.0",
            "name": self.display_name,
            "description": self.description,
            "functions": [
                {
                    "name": tool.get("function", {}).get("name", "unknown"),
                    "description": tool.get("function", {}).get("description", ""),
                    "parameters": tool.get("function", {}).get("parameters", {})
                }
                for tool in self.tools
            ],
            "settings": {
                "model": self.model,
                "temperature": self.temperature,
                "role": self.role
            },
            "metadata": self.metadata
        }

    def _to_openai_assistant_schema(self) -> Dict[str, Any]:
        """
        Export to OpenAI Assistants API format (Stub - v2.0 planned).

        Based on OpenAI Assistants API specification:
        https://platform.openai.com/docs/assistants/overview

        OpenAI Assistant Format:
        {
            "id": "asst_xxx",
            "object": "assistant",
            "created_at": timestamp,
            "name": "Assistant Name",
            "description": "Assistant description",
            "model": "gpt-4",
            "instructions": "System instructions",
            "tools": [...],
            "metadata": {...}
        }
        """
        return {
            "_format": "openai-assistant",
            "_status": "stub",
            "_note": "Full OpenAI Assistants API compatibility planned for v2.0",
            "id": f"asst_{self.name}",
            "object": "assistant",
            "created_at": int(datetime.fromisoformat(self.created_at.replace("Z", "+00:00")).timestamp()),
            "name": self.display_name,
            "description": self.description,
            "model": self.model,
            "instructions": self.instructions,
            "tools": self._convert_tools_to_openai_format(),
            "file_ids": [],
            "metadata": {
                **self.metadata,
                "role": self.role,
                "temperature": self.temperature,
                "framework": "twisterlab"
            }
        }

    def _convert_tools_to_microsoft_format(self) -> List[Dict[str, Any]]:
        """
        Convert TwisterLab tools to Microsoft Agent Framework format.

        Microsoft Tool Format:
        {
            "type": "function",
            "function": {
                "name": "function_name",
                "description": "Function description",
                "parameters": {...}
            }
        }
        """
        microsoft_tools = []

        for tool in self.tools:
            if tool.get("type") == "function":
                microsoft_tools.append({
                    "type": "function",
                    "function": {
                        "name": tool["function"]["name"],
                        "description": tool["function"].get("description", ""),
                        "parameters": tool["function"].get("parameters", {
                            "type": "object",
                            "properties": {},
                            "required": []
                        })
                    }
                })

        return microsoft_tools

    def _convert_tools_to_openai_format(self) -> List[Dict[str, Any]]:
        """
        Convert TwisterLab tools to OpenAI Assistants API format.

        OpenAI Tool Format (same as Microsoft):
        {
            "type": "function" | "code_interpreter" | "retrieval",
            "function": {...}
        }
        """
        # OpenAI format is similar to Microsoft format
        return self._convert_tools_to_microsoft_format()

    def export_to_file(self, filepath: str, format: str = "microsoft") -> None:
        """
        Export agent schema to JSON file.

        Args:
            filepath: Output file path
            format: Target format (microsoft, langchain, semantic-kernel, openai)
        """
        schema = self.to_schema(format)

        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(schema, f, indent=2, ensure_ascii=False)

    def __repr__(self) -> str:
        return f"TwisterAgent(name='{self.name}', role='{self.role}', tools={len(self.tools)})"


class AutonomousTwisterAgent(TwisterAgent, ABC):
    """
    Enhanced TwisterAgent with autonomous capabilities.

    Features:
    - Self-monitoring and health tracking
    - Auto-recovery mechanisms
    - Prometheus metrics integration
    - Structured logging with correlation IDs
    - Autonomous decision making
    - Performance optimization
    """

    def __init__(
        self,
        name: str,
        display_name: str,
        description: str,
        role: str = "assistant",
        instructions: Optional[str] = None,
        tools: Optional[List[Dict[str, Any]]] = None,
        model: str = "llama-3.2",
        temperature: float = 0.7,
        metadata: Optional[Dict[str, Any]] = None,
        # Autonomous capabilities
        enable_autonomy: bool = True,
        health_check_interval: int = 60,  # seconds
        auto_recovery: bool = True,
        max_recovery_attempts: int = 3,
        performance_monitoring: bool = True,
    ):
        super().__init__(
            name=name,
            display_name=display_name,
            description=description,
            role=role,
            instructions=instructions,
            tools=tools,
            model=model,
            temperature=temperature,
            metadata=metadata,
        )

        # Autonomous configuration
        self.enable_autonomy = enable_autonomy
        self.health_check_interval = health_check_interval
        self.auto_recovery = auto_recovery
        self.max_recovery_attempts = max_recovery_attempts
        self.performance_monitoring = performance_monitoring

        # Runtime state
        self.is_running = False
        self.start_time = None
        self.last_health_check = None
        self.health_status = HealthStatus(agent_name=name)
        self.correlation_id = None

        # Background tasks
        self._health_monitor_task: Optional[asyncio.Task] = None
        self._performance_monitor_task: Optional[asyncio.Task] = None

        # Recovery mechanisms
        self.recovery_strategies: List[Callable] = []
        self._setup_recovery_strategies()

        # Prometheus metrics
        self._setup_metrics()

        # Structured logging
        self.logger = logging.getLogger(f"agent.{name}")
        self._setup_structured_logging()

    def _setup_metrics(self):
        """Initialize Prometheus metrics for this agent."""
        if not self.performance_monitoring:
            return

        # Execution metrics
        self.execution_counter = Counter(
            f'twisterlab_agent_{self.name}_executions_total',
            f'Total executions for {self.display_name}',
            ['status', 'operation']
        )

        self.execution_duration = Histogram(
            f'twisterlab_agent_{self.name}_execution_duration_seconds',
            f'Execution duration for {self.display_name}',
            ['operation']
        )

        # Health metrics
        self.health_status_gauge = Gauge(
            f'twisterlab_agent_{self.name}_health_status',
            f'Health status for {self.display_name} (0=unknown, 1=healthy, 2=degraded, 3=unhealthy, 4=critical)',
            []
        )

        self.error_rate_gauge = Gauge(
            f'twisterlab_agent_{self.name}_error_rate',
            f'Error rate for {self.display_name}',
            []
        )

        # Resource metrics
        self.memory_usage_gauge = Gauge(
            f'twisterlab_agent_{self.name}_memory_usage_mb',
            f'Memory usage for {self.display_name}',
            []
        )

        self.cpu_usage_gauge = Gauge(
            f'twisterlab_agent_{self.name}_cpu_usage_percent',
            f'CPU usage for {self.display_name}',
            []
        )

        # Agent info
        self.agent_info = Info(
            f'twisterlab_agent_{self.name}_info',
            f'Information about {self.display_name}'
        )
        self.agent_info.info({
            'name': self.name,
            'display_name': self.display_name,
            'description': self.description,
            'model': self.model,
            'version': self.metadata.get('version', '1.0.0')
        })

    def _setup_structured_logging(self):
        """Configure structured logging for this agent."""
        # Ensure logger has proper formatting
        if not self.logger.handlers:
            handler = logging.StreamHandler()
            formatter = logging.Formatter(
                json.dumps({
                    'timestamp': '%(asctime)s',
                    'level': '%(levelname)s',
                    'agent': self.name,
                    'correlation_id': '%(correlation_id)s',
                    'message': '%(message)s',
                    'extra': '%(extra)s'
                })
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
            self.logger.setLevel(logging.INFO)

    def _setup_recovery_strategies(self):
        """Setup default recovery strategies."""
        self.recovery_strategies = [
            self._recovery_restart_services,
            self._recovery_clear_cache,
            self._recovery_reset_state,
            self._recovery_escalate_to_maestro
        ]

    async def start(self):
        """Start the autonomous agent."""
        if self.is_running:
            return

        self.is_running = True
        self.start_time = datetime.now(timezone.utc)
        self.correlation_id = str(uuid.uuid4())

        self.logger.info(
            f"Starting autonomous agent {self.display_name}",
            extra={
                'correlation_id': self.correlation_id,
                'agent_state': 'starting'
            }
        )

        # Start background monitoring tasks
        if self.enable_autonomy:
            self._health_monitor_task = asyncio.create_task(self._health_monitor_loop())
            if self.performance_monitoring:
                self._performance_monitor_task = asyncio.create_task(self._performance_monitor_loop())

        # Initial health check
        await self._perform_health_check()

    async def stop(self):
        """Stop the autonomous agent."""
        if not self.is_running:
            return

        self.logger.info(
            f"Stopping autonomous agent {self.display_name}",
            extra={
                'correlation_id': self.correlation_id,
                'agent_state': 'stopping'
            }
        )

        self.is_running = False

        # Cancel background tasks
        if self._health_monitor_task:
            self._health_monitor_task.cancel()
        if self._performance_monitor_task:
            self._performance_monitor_task.cancel()

        # Final health update
        self.health_status.status = "stopped"
        self._update_health_metrics()

    async def execute(self, task: str, context: Optional[Dict[str, Any]] = None) -> Any:
        """Execute agent task with monitoring and error handling."""
        correlation_id = context.get('correlation_id', str(uuid.uuid4())) if context else str(uuid.uuid4())

        start_time = datetime.now(timezone.utc)
        success = False
        error_message = None

        try:
            # Pre-execution health check
            if self.enable_autonomy:
                await self._perform_health_check()

            # Execute the task
            self.logger.info(
                f"Executing task: {task}",
                extra={
                    'correlation_id': correlation_id,
                    'task': task,
                    'context': context
                }
            )

            result = await self._execute_task(task, context)

            success = True
            return result

        except Exception as e:
            error_message = str(e)
            self.logger.error(
                f"Task execution failed: {error_message}",
                extra={
                    'correlation_id': correlation_id,
                    'task': task,
                    'error': error_message,
                    'exception_type': type(e).__name__
                },
                exc_info=True
            )

            # Attempt auto-recovery if enabled
            if self.auto_recovery and self.health_status.recovery_attempts < self.max_recovery_attempts:
                await self._attempt_recovery(correlation_id, task, context)

            raise

        finally:
            # Update metrics
            execution_time = (datetime.now(timezone.utc) - start_time).total_seconds()

            if self.performance_monitoring:
                self.execution_counter.labels(
                    status='success' if success else 'error',
                    operation=task
                ).inc()

                self.execution_duration.labels(operation=task).observe(execution_time)

            # Update health status
            if success:
                self.health_status.checks_passed += 1
            else:
                self.health_status.checks_failed += 1
                self.health_status.last_error = error_message

            self._update_health_metrics()

            # Publish status to the status bus (best-effort; do not block the health loop)
            try:
                bus = await get_default_bus()
                status_payload = {
                    "agent": self.name,
                    "status": self.health_status.status,
                    "last_check": self.health_status.last_check,
                    "checks_passed": self.health_status.checks_passed,
                    "checks_failed": self.health_status.checks_failed,
                    "memory_usage_mb": self.health_status.memory_usage_mb,
                    "cpu_usage_percent": self.health_status.cpu_usage_percent,
                    "error_rate": self.health_status.error_rate,
                    "recovery_attempts": self.health_status.recovery_attempts,
                }
                # Run publish as a background task; best-effort
                asyncio.create_task(bus.publish_status(self.name, status_payload))
            except Exception:
                # Non-blocking; ignore status bus failures
                pass

    @abstractmethod
    async def _execute_task(self, task: str, context: Optional[Dict[str, Any]] = None) -> Any:
        """Execute the actual agent task (to be implemented by subclasses)."""
        pass

    async def _health_monitor_loop(self):
        """Background health monitoring loop."""
        while self.is_running:
            try:
                await self._perform_health_check()
                await asyncio.sleep(self.health_check_interval)
            except Exception as e:
                self.logger.error(f"Health monitor error: {e}", exc_info=True)
                await asyncio.sleep(10)  # Shorter retry interval on error

    async def _performance_monitor_loop(self):
        """Background performance monitoring loop."""
        while self.is_running:
            try:
                await self._update_performance_metrics()
                await asyncio.sleep(30)  # Update every 30 seconds
            except Exception as e:
                self.logger.error(f"Performance monitor error: {e}", exc_info=True)
                await asyncio.sleep(10)

    async def _perform_health_check(self):
        """Perform comprehensive health check."""
        try:
            # Basic health indicators
            self.health_status.last_check = datetime.now(timezone.utc).isoformat() + "Z"

            if self.start_time:
                self.health_status.uptime_seconds = (
                    datetime.now(timezone.utc) - self.start_time
                ).total_seconds()

            # Calculate error rate
            total_checks = self.health_status.checks_passed + self.health_status.checks_failed
            if total_checks > 0:
                self.health_status.error_rate = self.health_status.checks_failed / total_checks

            # Determine health status
            if self.health_status.error_rate > 0.5:
                self.health_status.status = "critical"
            elif self.health_status.error_rate > 0.2:
                self.health_status.status = "unhealthy"
            elif self.health_status.error_rate > 0.1:
                self.health_status.status = "degraded"
            else:
                self.health_status.status = "healthy"

            # Agent-specific health checks
            await self._agent_specific_health_check()

            self._update_health_metrics()

        except Exception as e:
            self.logger.error(f"Health check failed: {e}", exc_info=True)
            self.health_status.status = "critical"
            self.health_status.last_error = str(e)

    async def _agent_specific_health_check(self):
        """Agent-specific health checks (can be overridden by subclasses)."""
        # Default implementation - subclasses should override
        pass

    async def _update_performance_metrics(self):
        """Update performance-related metrics."""
        try:
            import psutil
            import os

            # Memory usage
            process = psutil.Process(os.getpid())
            memory_mb = process.memory_info().rss / 1024 / 1024
            self.health_status.memory_usage_mb = memory_mb
            self.memory_usage_gauge.set(memory_mb)

            # CPU usage (over last interval)
            cpu_percent = process.cpu_percent(interval=1.0)
            self.health_status.cpu_usage_percent = cpu_percent
            self.cpu_usage_gauge.set(cpu_percent)

        except ImportError:
            # psutil not available
            pass
        except Exception as e:
            self.logger.error(f"Performance metrics update failed: {e}")

    def _update_health_metrics(self):
        """Update Prometheus health metrics."""
        if not self.performance_monitoring:
            return

        # Status mapping
        status_map = {
            "unknown": 0,
            "healthy": 1,
            "degraded": 2,
            "unhealthy": 3,
            "critical": 4,
            "stopped": 5
        }

        self.health_status_gauge.set(status_map.get(self.health_status.status, 0))
        self.error_rate_gauge.set(self.health_status.error_rate)

    async def _attempt_recovery(self, correlation_id: str, failed_task: str, context: Optional[Dict[str, Any]]):
        """Attempt to recover from a failure."""
        self.health_status.recovery_attempts += 1

        self.logger.info(
            f"Attempting recovery (attempt {self.health_status.recovery_attempts}/{self.max_recovery_attempts})",
            extra={
                'correlation_id': correlation_id,
                'failed_task': failed_task,
                'recovery_attempt': self.health_status.recovery_attempts
            }
        )

        for strategy in self.recovery_strategies:
            try:
                success = await strategy(correlation_id, failed_task, context)
                if success:
                    self.logger.info(
                        f"Recovery successful using {strategy.__name__}",
                        extra={
                            'correlation_id': correlation_id,
                            'recovery_strategy': strategy.__name__
                        }
                    )
                    self.health_status.recovery_attempts = 0  # Reset on success
                    return
            except Exception as e:
                self.logger.error(
                    f"Recovery strategy {strategy.__name__} failed: {e}",
                    extra={
                        'correlation_id': correlation_id,
                        'recovery_strategy': strategy.__name__,
                        'error': str(e)
                    }
                )

        self.logger.error(
            f"All recovery attempts failed for task {failed_task}",
            extra={
                'correlation_id': correlation_id,
                'failed_task': failed_task,
                'max_attempts': self.max_recovery_attempts
            }
        )

    async def _recovery_restart_services(self, correlation_id: str, failed_task: str, context: Optional[Dict[str, Any]]) -> bool:
        """Default recovery: restart related services."""
        # Implementation depends on the specific agent
        return False

    async def _recovery_clear_cache(self, correlation_id: str, failed_task: str, context: Optional[Dict[str, Any]]) -> bool:
        """Recovery: clear caches and reset state."""
        # Implementation depends on the specific agent
        return False

    async def _recovery_reset_state(self, correlation_id: str, failed_task: str, context: Optional[Dict[str, Any]]) -> bool:
        """Recovery: reset agent state."""
        # Implementation depends on the specific agent
        return False

    async def _recovery_escalate_to_maestro(self, correlation_id: str, failed_task: str, context: Optional[Dict[str, Any]]) -> bool:
        """Recovery: escalate to maestro agent."""
        # This would integrate with the maestro orchestrator
        return False

    def get_health_status(self) -> HealthStatus:
        """Get current health status."""
        return self.health_status

    def get_metrics_endpoint(self) -> Dict[str, Any]:
        """Get metrics for monitoring endpoints."""
        return {
            "agent_name": self.name,
            "health_status": self.health_status.status,
            "uptime_seconds": self.health_status.uptime_seconds,
            "checks_passed": self.health_status.checks_passed,
            "checks_failed": self.health_status.checks_failed,
            "error_rate": self.health_status.error_rate,
            "memory_usage_mb": self.health_status.memory_usage_mb,
            "cpu_usage_percent": self.health_status.cpu_usage_percent,
            "recovery_attempts": self.health_status.recovery_attempts,
            "last_error": self.health_status.last_error,
            "last_check": self.health_status.last_check
        }
