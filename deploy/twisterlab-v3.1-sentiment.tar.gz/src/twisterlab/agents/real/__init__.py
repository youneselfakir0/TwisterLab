"""Real agents package."""

from .browser_agent import BrowserAgent  # noqa: F401

__all__ = ["BrowserAgent"]
