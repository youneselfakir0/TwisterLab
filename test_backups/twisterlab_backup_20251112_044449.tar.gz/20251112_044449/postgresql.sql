--
-- TwisterLab PostgreSQL Database Dump
-- Dumped at: 2025-11-12T04:44:49.972836+00:00
--

-- Database: twisterlab
-- MOCK DATA FOR TESTING

CREATE TABLE IF NOT EXISTS tickets (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255),
    status VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sops (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255),
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data
INSERT INTO tickets (title, status) VALUES
    ('Network connectivity issue', 'resolved'),
    ('Software installation request', 'open'),
    ('Hardware repair', 'in_progress');

INSERT INTO sops (name, content) VALUES
    ('Network Troubleshooting', 'Step 1: Check cables...'),
    ('Software Installation', 'Step 1: Download package...');

-- End of dump
